class Main {
  public static void main(String[] args) {
    Book b1 = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling", 309);

    Book b2 = new Book("Niccolo Machiavelli", "The Prince", 71);

    Book b3 = new Book("Encyclopedia Britannica");

    Book b4 = new Book();
  }
}
