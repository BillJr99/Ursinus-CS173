class Book {
  String title;
  String author;
  int pages;

  // Constructors are methods whose name is that of the class.
  // They are called automatically by the "new" keyword.
  Book(String _author, String _title, int _pages) {
    this.title = _title;
    this.author = _author;
    this.pages = _pages;
  }

  /* You can create as many constructors as you wish, as long
     as each one has its own set of parameters.  It is a good 
    idea to initialize all object variables, even if their 
    values are not given by the constructor parameters. */
  Book(String _title) {
    this.title = _title;
    this.author = "Unknown";
    this.pages = 0;
  }

  // This is called a "default constructor" as it has no parameters.
  Book() {
    this.title = "Unknown";
    this.author = "Unknown";
    this.pages = 0;
  }
}