public interface Home {
    public int cook();
 
    public void makeBed();
}