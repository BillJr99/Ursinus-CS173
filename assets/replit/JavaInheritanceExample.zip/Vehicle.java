public interface Vehicle {
     // An interface shows how a program
     // Can interact with an object.
     // It defines common behaviors - no data/fields, just methods!
      
     public void unlock();
      
     public void lock();
      
     public void drive(int speed);
      
     // return a boolean if the vehicle is parked
     public boolean stop();
      
     public int getSpeed();
}