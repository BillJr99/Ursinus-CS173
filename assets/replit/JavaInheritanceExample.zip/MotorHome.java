public class MotorHome implements Vehicle, Home {
     int gear;
     boolean parked;
     int speed;
     boolean locked;
     boolean bedmade;
      
     public MotorHome() {
       this.gear = 1; 
       this.parked = true;
       this.speed = 0;
       this.locked = true;
       this.bedmade = true;
     }
      
     public void unlock() {
       this.locked = false;
     }
      
     public void lock() {
       this.locked = true;
     }
      
     public void drive(int speed) {
       if(this.parked == true) {
         this.parked = false;
       }
      
       this.speed = speed;
       this.gear = this.speed / 5;
     }
      
     // return a boolean if the vehicle is parked
     public boolean stop() {
       this.speed = 0;
       this.gear = 1;
       return this.parked;
     }
      
     public int cook() {
       return 1; // yum?
     }
      
     public void makeBed() {
       this.bedmade = true;
     }
      
     public boolean isBedMade() {
       return this.bedmade;
     }
      
     public int getSpeed() {
       return this.speed;
     }
}