public class Car implements Vehicle {
     int gear;
     boolean parked;
     int speed;
     boolean locked;
      
     public Car() {
       this.gear = 1; 
       this.parked = true;
       this.speed = 0;
       this.locked = true;
     }
      
     public int getSpeed() {
       return this.speed;
     }
      
     public void unlock() {
       this.locked = false;
     }
      
     public void lock() {
       this.locked = true;
     }
      
     public void drive(int speed) {
       if(this.parked == true) {
         this.parked = false;
       }
      
       this.speed = speed;
       this.gear = this.speed / 10;
     }
      
     // return a boolean if the vehicle is parked
     public boolean stop() {
       this.speed = 0;
       this.gear = 1;
       return this.parked;
     }
}