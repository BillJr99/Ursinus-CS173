import java.util.Random;

class Main {
     public static void main(String[] args) {
       Random r = new Random();
      
       Vehicle[] vehicles = new Vehicle[2];
      
       Car c = new Car();
       MotorHome m = new MotorHome();
      
       vehicles[0] = c;
       vehicles[1] = m;
      
       m.makeBed();
      
       for(Vehicle v: vehicles) {
         v.drive(r.nextInt(50));
       }
      
       // Methods in the Interface can be called on variables whose type is just the interface, no matter what it really is!
       System.out.println("How fast is the car driving? " + vehicles[0].getSpeed());
      
       System.out.println("How about the Motor Home? " + vehicles[1].getSpeed());
      
       // Methods specific to a class can always be called from the object.
       System.out.println("Is the Motor Home bed made? " + m.isBedMade());
     }
}