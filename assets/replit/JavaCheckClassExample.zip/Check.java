public class Check {
  public String signature;
  public double amount; 
  public String textAmount;
  public String date;
  public String memo;
  public String recipient;

  public void print() {
    System.out.println("This is a check to " + recipient);
    System.out.println("Date: " + date);
    System.out.println(textAmount + " (" + amount + ")");
    System.out.println(signature);
    System.out.println(memo);
  }
}