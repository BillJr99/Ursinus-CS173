public class Main {
  public static void main(String[] args) {
    Check paycheck = new Check();
    Check electricBill = new Check();

    paycheck.amount = 500;
    paycheck.textAmount = "Five hundred dollars and no cents";
    paycheck.recipient = "ME!!!!";
    paycheck.date = "November 16, 2020";
    paycheck.memo = "This is for all your hard work.";

    electricBill.amount = 40;
    electricBill.textAmount = "Fourty dollars";
    electricBill.date = "November 16, 2020";
    electricBill.recipient = "PECO";

    System.out.println(paycheck.amount);
    System.out.println(electricBill.amount);

    System.out.println(paycheck);
    System.out.println(electricBill);

    paycheck.print();
    electricBill.print();
  }
}