class Book {
  // These are called "fields"
  private String title;
  private String author;
  private int pages;

  // This is a "mutator" method.  I call it a "setter" method.
  public void setPages(int _pages) {
    if(_pages >= 0) {
      this.pages = _pages;
    }
  }

  // This is an "accessor" method.  I call it a "getter" method.
  public int getPages() {
    return this.pages;
  }

  /* It is a good practice to have getter and setter functions for
     each of your field variables, as long as you want them to be 
     readable or writable by others. */

  // This is a helper method.
  public void print() {
    System.out.println(this.title + ". " + this.author + ". (" + 
                       this.pages + " pages)");
  }

  // Constructors are methods whose name is that of the class.
  // They are called automatically by the "new" keyword.
  Book(String _author, String _title, int _pages) {
    this.title = _title;
    this.author = _author;
    this.pages = _pages;
  }

  /* You can create as many constructors as you wish, as long
     as each one has its own set of parameters.  It is a good 
    idea to initialize all object variables, even if their 
    values are not given by the constructor parameters. */
  Book(String _title) {
    this.title = _title;
    this.author = "Unknown";
    this.pages = 0;
  }

  // This is called a "default constructor" as it has no parameters.
  Book() {
    this.title = "Unknown";
    this.author = "Unknown";
    this.pages = 0;
  }
}