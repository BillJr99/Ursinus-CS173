// https://csawesome.runestone.academy/runestone/books/published/csawesome/Unit8-2DArray/routeCipherA.html

public class Main
{
  /** Places a string into letterBlock in row-major order.
  *   @param str the string to be processed
  *   Postcondition:
  *     if str.length() < numRows * numCols, "A" in each unfilled cell
  *     if str.length() > numRows * numCols, trailing characters are ignored
  *   @return The message block
  */
  public static char[][] fillBlock(String str, int numRows, int numCols) { 
    /* to be implemented in part (a) */ 
  }

  /** Encrypts a message.
  *   @param message the string to be encrypted
  *   @return the encrypted message;
  *           if message is the empty string, returns the empty string
  */
  public static String encryptMessage(String message, int numRows, int numCols) { 
    /* to be implemented in part (b) */ 
  } 

  public static void main(String[] args) {
    // how will you know this works?
    String message = "Meet at noon"; 
    String encrypted = encryptMessage(message, 3, 5);
    System.out.println(encrypted);
  }
}