import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int numKids = -1;
    Scanner input = new Scanner(System.in);

    do {
      System.out.println("Enter the number of children");
      numKids = input.nextInt();
    } while(numKids < 0);

    System.out.println("You have " + numKids + " kids!");
  }
}