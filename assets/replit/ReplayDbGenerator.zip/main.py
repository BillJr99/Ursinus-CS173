import sqlite3
import time
import random

# stmt contains placeholder ?'s for params
# params is a tuple (val1, val2, ...)
def query(con, stmt, params=None):
  cur = con.cursor()
  if params is None:
    result = cur.execute(stmt)
  else:
    result = cur.execute(stmt, params)
  con.commit()
  return result

def conquery(stmt, params=None, closedb=True):
  con = sqlite3.connect('main.db')

  res = query(con, stmt, params)

  if closedb == True:
    con.close()

  return res, con

res, con = conquery("DROP TABLE IF EXISTS DATA;")
res, con = conquery("CREATE TABLE IF NOT EXISTS DATA (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, DATA TEXT);")

colorfile = 'colors.txt'
postitfile = 'postits.txt'

canvaswidth = 1200
numcols = 20
gridwidth = canvaswidth / numcols
subcols = 5
canvasheight = 432
numrows = 12
gridheight = canvasheight / numrows
subrows = 3
randomize = True

colorf = open(colorfile, 'r')
postitf = open(postitfile, 'r')

colorlines = colorf.readlines()
postitlines = postitf.readlines()

colors = []

lineno = 2
while len(colorlines[lineno].strip()) > 0 and lineno < len(colorlines):
  colorline = colorlines[lineno].split(" ")

  red = int(colorline[2])
  green = int(colorline[4])
  blue = int(colorline[6])

  red = "0x{:02x}".format(red).replace("0x", "")
  green = "0x{:02x}".format(green).replace("0x", "")
  blue = "0x{:02x}".format(blue).replace("0x", "")

  htmlcolor = "#" + red + green + blue

  #print(htmlcolor)

  colors.append(htmlcolor)

  lineno = lineno + 1

# randomizer
if randomize == True:
  random.shuffle(postitlines)

for line in postitlines:
  if len(line.strip()) > 0:
    linedata = line.strip().replace("\t", " ").replace("  ", " ").replace("  ", " ").split(" ")

    #print(linedata)
    col = ord(linedata[0].lower()) - 97 # A=0, B=1, C=2, ...
    row = int(linedata[1]) - 1

    linedata = linedata[2:]

    linevals = []
    for i in range(len(linedata)):
      coloffset = int(i % subcols)
      rowoffset = int(i / subcols)
      color = int(linedata[i])

      lineval = {}
      lineval['coloffset'] = coloffset
      lineval['rowoffset'] = rowoffset
      lineval['color'] = color

      linevals.append(lineval)

    if randomize == True:
      random.shuffle(linevals)

    for i in range(len(linevals)):
      lineval = linevals[i]

      #print(linedata[i])
      color = colors[int(lineval['color'])]
      #print(color)

      coloffset = int(lineval['coloffset'])
      rowoffset = int(lineval['rowoffset'])

      xsquare = int(col) * subcols + coloffset
      ysquare = int(row) * subrows + rowoffset
      leftx = int(xsquare * gridwidth * 1.0 / subcols)
      topy = int(ysquare * gridheight * 1.0 / subrows)
      colorvalue = color

      data = str(leftx) + "," + str(topy) + "," + str(int(gridwidth / subcols)) + "," + str(int(gridheight / subrows)) + "," + colorvalue + "," + str(xsquare) + "," + str(ysquare)
      res, con = conquery("INSERT INTO DATA (DATA) VALUES (?)", params=(data,))
      time.sleep(0.001)

res, con = conquery("SELECT * FROM DATA;", closedb=False)
for row in res.fetchall():
  print(row)

con.close()