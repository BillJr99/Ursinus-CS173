import java.util.ArrayList;

public class Movie {
  // Movies have:
  // title
  // run time
  // genre
  // director
  // actor

  public String title;
  public double runtime;
  public String genre;
  public String director;
  public ArrayList<String> actors;

  public void watch() {
    System.out.println("You watch the movie " + title + " for " + runtime + " hours!");
  }

  public static void previews() {
    System.out.println("Watch some coming attractions for the movie!");
  }
}