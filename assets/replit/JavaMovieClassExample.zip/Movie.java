import java.util.ArrayList;

public class Movie {
  // Movies have:
  // title
  // run time
  // genre
  // director
  // actor

  public String title;
  private double runtime;
  public String genre;
  public String director;
  public ArrayList<String> actors;
  public int seat;

  public Movie() {
    this.title = "Unknown";
    this.runtime = 0;
    this.genre = "Unknown";
    this.director = "Unknown";
    this.actors = new ArrayList<String>();
    this.seat = 0;
  }

  public Movie(String _title, double _runtime, String _director, String _genre) {
    this.title = _title;
    this.runtime = _runtime;
    this.genre = _genre;
    this.director = _director;

    this.actors = new ArrayList<String>();
    this.seat = 0;
  }

  // title director runtime
  public Movie(String _title, double _runtime, String _director) {
    this.title = _title;
    this.runtime = _runtime;
    this.director = _director;

    this.genre = "Unknown";
    this.actors = new ArrayList<String>();
    this.seat = 0;
  }

  public void setRuntime(double _runtime) {
    if(_runtime > 0) {
      this.runtime = _runtime;
    }
  }

  public getRuntime() {
    return this.runtime;
  }
  
  public void watch() {
    System.out.println("You watch the movie " + title + " for " + runtime + " hours!");
  }

  public int getSeat() {
    return seat;
  }

  public static void goToConcessions(String whatToBuy) {
    System.out.println("Go buy some " + whatToBuy);
  }

  public static void previews() {
    // static functions can't use object variables!
    System.out.println("Watch some coming attractions for the movie!");
  }
}