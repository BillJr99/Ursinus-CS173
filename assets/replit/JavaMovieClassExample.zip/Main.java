import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    Movie lotr = new Movie("Lord of the Rings", 3.8, "Peter Jackson");
    Movie et = new Movie("ET", 1.5, "Spielberg");

    lotr.actors = new ArrayList<String>();
    lotr.actors.add("Orlando Bloom");
    lotr.actors.add("Elijah Wood");

    //et.runtime = -1;
    et.setRuntime(-1);
    System.out.println(et.runtime);

    Movie.previews();
    et.watch();

    Movie.previews();
    lotr.watch();

    for(String actor : lotr.actors) {
      System.out.println(actor);
    }
  }
}