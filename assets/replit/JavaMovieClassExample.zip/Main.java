import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    Movie lotr = new Movie();
    Movie et = new Movie();

    lotr.title = "Lord of the Rings";
    lotr.director = "Peter Jackson";
    lotr.runtime = 3.8;

    et.title = "ET";
    et.director = "Spielberg";
    et.runtime = 1.5;

    ArrayList<String> lotrActors = lotr.actors;
    lotrActors = new ArrayList<String>();
    lotrActors.add("Orlando Bloom");
    lotrActors.add("Elijah Wood");

    System.out.println(et.runtime);

    Movie.previews();
    et.watch();

    Movie.previews();
    lotr.watch();

    for(String actor : lotrActors) {
      System.out.println(actor);
    }
  }
}