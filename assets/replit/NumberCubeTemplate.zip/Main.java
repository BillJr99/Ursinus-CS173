// https://csawesome.runestone.academy/runestone/books/published/csawesome/Unit6-Arrays/numberCubeB.html

class Main {
  public static int getLongestRun(int[] values) {
    /* to be completed */
  }

  public static void main(String[] args) {
    // https://csawesome.runestone.academy/runestone/books/published/csawesome/Unit6-Arrays/numberCubeB.html

    int[] values = {3, 5, 6, 6, 3, 6, 4, 4, 4, 2, 6, 4, 1, 1, 1, 1};
    int longestRunIdx = getLongestRun(values);

    if(longestRunIdx != 12){
        System.out.println("Your code does not return the correct index.");

        if(longestRunIdx == 2 || longestRunIdx == 6)
            System.out.println("It is returning the start index of a run, but that run is not the longest.");

        System.out.println("Remember that your code must return the start index of the longest run of tosses.");
    } else {
        System.out.println("Looks like your code works well!");
    }    
  }
}