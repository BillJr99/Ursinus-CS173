class Main {
  public static int min(int a, int b) {
    // return a if a < b
    // otherwise return b
    if(a < b) {
      return a;
    } else {
      return b;
    }
  }

  public static boolean compareStrings(String str1, String str2) {
    boolean isEqual = true;

    if(str1.length() != str2.length()) {
      isEqual = false;
    }

    int minlength = min(str1.length(), str2.length()); // Math.min(str1.length(), str2.length());
    System.out.println("The smallest string has length " + minlength);

    for(int i = 0; i < minlength; i++) {
      if(str1.charAt(i) != str2.charAt(i)) {
        isEqual = false;
      } 
    }

    return isEqual;
  }

  public static void main(String[] args) {
    boolean equal1 = compareStrings("Book", "Bookkeeper");
    System.out.println(equal1);

    boolean equal2 = compareStrings("Cattail", "Hat");
    System.out.println(equal2);

    boolean equal3 = compareStrings("Hello", "World");
    System.out.println(equal3);

    boolean equal4 = compareStrings("Hello", "Hello");
    System.out.println(equal4);    
  }
}