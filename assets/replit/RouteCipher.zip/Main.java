// https://runestone.academy/ns/books/published/apcsareview/Array2dBasics/routeCipherA.html

public class Main
{
  /** Places a string into letterBlock in row-major order.
  *   @param str the string to be processed
  *   Postcondition:
  *     if str.length() < numRows * numCols, "A" in each unfilled cell
  *     if str.length() > numRows * numCols, trailing characters are ignored
  *   @return The message block
  */
  public static char[][] fillBlock(String str, int numRows, int numCols) { 
    /* to be implemented in part (a) */ 

    char[][] block = new char[numRows][numCols];

    for(int i = 0; i < numRows * numCols; i++) {
      char ch = 'A'; // fill in remaining characters with 'A'
      if(i < str.length()) {
        ch = str.charAt(i); // fill in up to length() characters in the block
      } 

      int row = i / numCols;
      int col = i % numCols;

      block[row][col] = ch;
    }

    return block;
  }

  /** Encrypts a message.
  *   @param message the string to be encrypted
  *   @return the encrypted message;
  *           if message is the empty string, returns the empty string
  */
  public static String encryptMessage(String message, int numRows, int numCols) { 
    /* to be implemented in part (b) */ 
    String result = "";

    char[][] block = fillBlock(message, numRows, numCols);

    // column major traversal
    for(int i = 0; i < block[0].length; i++) {
      for(int j = 0; j < block.length; j++) {
        result = result + block[j][i];
      }
    }

    return result;
  } 

  public static void main(String[] args) {
    String message = "Meet at noon"; // test with a string of exact size, too big, too small
    String encrypted = encryptMessage(message, 3, 5);
    System.out.println(encrypted);
  }
}