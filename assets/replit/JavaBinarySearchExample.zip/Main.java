import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

class Main {
  public static int binarySearch(int[] arr, int key, int left, int right) {
    if(right == left && arr[left] != key) {
      System.out.println("Couldn't find the value!");
      return -1;
    }

    int mid = (right + left) / 2; // arr.length / 2

    System.out.println("Checking position " + mid + " for " + key + ", finding " + arr[mid]);

    if(arr[mid] == key) {
      return mid;
    } else if(key < arr[mid]) {
      System.out.println("I didn't find it, but I know it's between 0 and " + mid);
      return binarySearch(arr, key, left, mid-1);
    } else { // key > arr[mid]
      System.out.println("I didn't find it, but I know it's between " + (mid + 1) + " and " + right);
      return binarySearch(arr, key, mid+1, right);
    }
  }

  public static int[] genRandomArray(int n) {
    int[] arr = new int[n];

    Random rnd = new Random();

    for(int i = 0; i < n; i++) {
      arr[i] = rnd.nextInt(2*n);
    }

    return arr;
  }


  public static void main(String[] args) {
    //int[] values = {1, 3, 5, 6, 8, 10, 12, 16, 19, 25};
    //int val = 19;

    int[] values = genRandomArray(1000);
    Arrays.sort(values);
    System.out.println(Arrays.toString(values));

    Scanner input = new Scanner(System.in);
    System.out.println("What value would you like to search for?");
    int val = input.nextInt();

    int idx = binarySearch(values, val, 0, values.length - 1);

    System.out.println("Binary Search returned index " + idx + " when searching for " + val);
  }
}