public class Main {
    public static void main(String[] args) {
        // println prints a "line" to the string
        System.out.println("Hello World!");
        System.out.println("Have a great day.");
    }
}