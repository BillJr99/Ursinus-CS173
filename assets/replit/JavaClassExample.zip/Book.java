public class Book {
  String title;
  String author;
  int pages;
}