# ASCIIArt

## Copyright

### <a href = "https://algs4.cs.princeton.edu/code/javadoc/edu/princeton/cs/algs4/Picture.html">Picture</a> library
Copyright &copy; 2000&ndash;2019 by Robert Sedgewick and Kevin Wayne.


### Rest of Code
Copyright &copy; 2020 by Christopher Tralie, License Apache2