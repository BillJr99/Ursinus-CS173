/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unittestingsample;

/**
 *
 * @author bill
 */
public class UnitTestingSample {

    /**
     * Return true if the text in string a is the same as the text in string b
     * @param a The first string to compare
     * @param b The second string to compare
     * @return The result of the comparison of the two strings
     */
    public static boolean stringEquals(String a, String b) {
        return (a == b);
    }
    
    /** 
     * Play the Fizz Buzz game, given the value n
     * @param n The value to evaluate
     * @return Fizz if the value is divisible by 3, 
     * Buzz if it is divisible by 5, 
     * FizzBuzz if it is divisible by both, 
     * and the number itself otherwise
     */
    public static String fizzBuzz(int n) {
        String result = Integer.toString(n);
        
        if(n % 3 == 0) {
            result = "Fizz";
        } else if(n % 5 == 0) {
            result = "Buzz";
        }
        
        return result;
    }
    
    /**
     * Given the price of an item and the tax rate, return the 
     * total cost of the item.  Do not add tax for non-taxable items.
     * @param price The price of the item (i.e., 5.95)
     * @param tax The tax rate (i.e., 0.06 for 6%)
     * @param taxable true if the item is taxable, false otherwise
     * @return The price of the item plus the applicable tax
     */
    public static double totalCost(double price, double tax, boolean taxable) {
        double result = price * tax;
        
        return result;
    }
    
    /**
     * A triangle is acute if the sum of the squares of its 
     * two shorter sides is greater than the square of the third side.
     * However, it is only a valid triangle if the sum of the smaller sides 
     * is also greater than the third side.
     * Determine if a triangle is an acute triangle given its three sides.
     * @param side1 An arbitrary side length of the triangle
     * @param side2 An arbitrary side length of the triangle
     * @param side3 An arbitrary side length of the triangle
     * @return True if the triangle is a valid triangle and acute, 
     * false otherwise
     */
    public static boolean isAcute(double side1, double side2, double side3) {
        boolean result = false;
        
        double longestSide = Math.max(side1, side2);
        longestSide = Math.max(longestSide, side3);
        
        double sumOfSmallerSides = side1 + side2 + side3 - longestSide;
        
        if(sumOfSmallerSides > longestSide) { // is it a valid triangle?
            // is it also acute?
            if(Math.pow(sumOfSmallerSides, 2) > Math.pow(longestSide, 2)) {
                result = true;
            }
        }
        
        return result;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
