# Homework 0

Please visit <a href = "http://www.ctralie.com/Teaching/CS173_S2020/Assignments/HW0/">this link</a> for more information