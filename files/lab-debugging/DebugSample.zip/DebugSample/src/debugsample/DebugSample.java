/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package debugsample;

/**
 *
 * @author wmongan
 */
public class DebugSample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x1 = 5;
        int y1 = 10;
        int x2 = -1;
        int y2 = 3;
        
        int xdiff = x2 - x1;
        int ydiff = y2 - y1;
        double slope = ydiff / xdiff;
        
        String point1 = "(" + x1 + ", " + y1 + ")";
        String point2 = "(" + x2 + ", " + y2 + ")";
        System.out.println("The slope of the line between " + point1 + " and " + point2 + " is " + slope);
        System.out.println("The correct value should be 1.1666666666666667");
    }
    
}
