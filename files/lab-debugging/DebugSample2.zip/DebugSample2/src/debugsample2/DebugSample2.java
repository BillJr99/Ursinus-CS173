/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package debugsample2;

/**
 *
 * @author bill
 */
public class DebugSample2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v0 = 5; // initial velocity is 5 m/s
        int t = 10; // we're moving for 10 seconds
        double a = 1; // we're accelerating at 1 meter per second per second
        double distanceByVelocity = v0 * t;
        double distanceByAcceleration = ((1 / 2) * a * Math.pow(t, 2));
        double distance = distanceByVelocity + distanceByAcceleration;
        
        // the answer should be 100 meters!
        System.out.println("After 10 seconds, we have traveled " + distance + " meters");
    }
    
}
