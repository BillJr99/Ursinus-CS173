class Main {
  public static void main(String[] args) {
    // Create some boolean variables
    boolean isRaining = false;
    boolean isWarm = false;

    boolean goOutside = !isRaining && isWarm;
    
    System.out.print("Is it warm and not raining outside? ");
    System.out.println(goOutside);

    boolean goOutsideDeMorgan = !(isRaining || !isWarm);

    System.out.print("How about now? ");
    System.out.println(goOutsideDeMorgan);
  }
}