import sqlite3

CREATE_DATA_TABLE = "CREATE TABLE IF NOT EXISTS DATA (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, DATA TEXT, NAME TEXT);"

TABLE_NAME = "robotspringboard2022"

# stmt contains placeholder ?'s for params
# params is a tuple (val1, val2, ...)
def query(con, stmt, params=None):
    cur = con.cursor()
    if params is None:
        result = cur.execute(stmt)
    else:
        result = cur.execute(stmt, params)
    con.commit()
    return result


if __name__ == '__main__':
    con = sqlite3.connect('main.db')
    res = query(con, CREATE_DATA_TABLE)
    res = query(con, "DELETE FROM DATA WHERE NAME=?;", params=(TABLE_NAME, ))
    con.close()
