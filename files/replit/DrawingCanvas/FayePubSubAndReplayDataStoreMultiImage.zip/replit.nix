{ pkgs }: {
	deps = [
   pkgs.vim
   pkgs.dig
   pkgs.unixtools.ping
   pkgs.nettools
		pkgs.nodejs-18_x
    pkgs.nodePackages.typescript-language-server
    pkgs.yarn
    pkgs.replitPackages.jest
	];
}