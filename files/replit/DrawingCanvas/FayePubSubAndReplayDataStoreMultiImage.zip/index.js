const express = require('express');
var app = express();

const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

// To specify CORS hosts
const allowedOrigins = [
  'billmongan.com',
  'billjr99.github.io'
];

var corsOptions = {
  origin: function(origin, callback) {
    if (!origin || allowedOrigins.some(allowedOrigin => origin.includes(allowedOrigin))) {
      callback(null, true);
    } else {
      console.error(`Blocked by CORS: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true
};

app.options('*', function(req, res) {
  if (!req.headers.origin) {
    res.sendStatus(200); // no origin just sends back 200 for non-browser requests
  } else {
    cors(corsOptions)(req, res, function() {
      res.sendStatus(200);
    });
  }
});

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware to check origin for endpoints
function checkOrigin(req, res, next) {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.some(allowedOrigin => origin.includes(allowedOrigin))) {
    next();
  } else {
    res.status(403).send('Forbidden: Invalid origin');
  }
}

// Faye Pub Sub
var http = require('http');
var faye = require('faye');

var server = http.createServer(app);
var bayeux = new faye.NodeAdapter({ mount: '/faye' });

bayeux.attach(server);

// Replay Data Store
const CREATE_DATA_TABLE = "CREATE TABLE IF NOT EXISTS DATA (ID INTEGER PRIMARY KEY AUTOINCREMENT, TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, DATA TEXT, NAME TEXT);";

app.post('/insert', checkOrigin, (req, res) => {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  let data = req.body.data;
  let name = req.query.name;

  if (name) {
    db.run(`INSERT INTO DATA (NAME, DATA) VALUES (?,?)`, [name, data]);
  } else {
    db.run(`INSERT INTO DATA (DATA) VALUES (?)`, [data]);
  }

  db.close();

  res.status(201).send('Created');
});

app.get('/retrieve', checkOrigin, (req, res) => {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  let name = req.query.name;
  let sql;

  if (name) {
    sql = `SELECT * FROM DATA WHERE NAME=? ORDER BY TIMESTAMP ASC;`;
    db.all(sql, [name], (err, rows) => {
      if (err) {
        throw err;
      }
      res.send(rows);
    });
  } else {
    sql = `SELECT * FROM DATA ORDER BY TIMESTAMP ASC;`;
    db.all(sql, [], (err, rows) => {
      if (err) {
        throw err;
      }
      res.send(rows);
    });
  }

  db.close();
});

// Run
server.listen(8000, function() {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  db.close();

  console.log("Faye and Server are listening on port 8000");
});