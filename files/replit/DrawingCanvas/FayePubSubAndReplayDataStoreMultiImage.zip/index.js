const express = require('express');
var app = express();

app.set('trust proxy', 1);

const rateLimit = require('express-rate-limit');

const sqlite3 = require('sqlite3').verbose();

const cors = require('cors');

// To specify CORS hosts of billmongan.com and billjr99's github pages deployments
const allowedOrigins = [
  'billmongan.com',
  'billjr99.github.io'
];

var corsOptions = {
  origin: function(origin, callback) {
    if (!origin || allowedOrigins.some(allowedOrigin => origin.includes(allowedOrigin))) {
      callback(null, true);
    } else {
      console.error(`Blocked by CORS: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true
};

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate Limiting Middleware
const limiter = rateLimit({
  windowMs: 1 * 60 * 1000, // K minutes
  max: 90, // limit each IP to N requests per windowMs
  message: 'Too many requests from this IP in a short time window. Please try again later.',
  keyGenerator: function (req, res) {
    return req.ip; // Using Express's built-in IP handling with trust proxy support
  }
});
app.use(limiter);

// Middleware to check origin for /isnert and /retrieve endpoints
function checkOrigin(req, res, next) {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.some(allowedOrigin => origin.includes(allowedOrigin))) {
    next();
  } else {
    res.status(403).send('Forbidden: Invalid origin');
  }
}

// IP blocks of Google Cloud Provider and replit
const allowedIPRanges = [
  '34.64.0.0/10',  // One of the large blocks assigned to GCP
  '35.186.0.0/16',
  '34.83.0.0/16'   // This specific block covers the IP 34.83.184.146
];

// Middleware to restrict /download endpoint to Google Cloud Provider / replit
const checkIP = (req, res, next) => {
  function ipToNumber(ip) {
    return ip.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0);
  }

  function cidrToRange(cidr) {
    const [ip, prefix] = cidr.split('/');
    const ipNum = ipToNumber(ip);
    const mask = ~((1 << (32 - prefix)) - 1);

    const start = ipNum & mask;
    const end = start + ~mask;

    return { start, end };
  }

  function ipRangeCheck(ip, ranges) {
    const ipNum = ipToNumber(ip);

    for (const range of ranges) {
      const { start, end } = cidrToRange(range);

      if (ipNum >= start && ipNum <= end) {
        return true;
      }
    }
    return false;
  }

  const clientIP = (req.headers['x-forwarded-for'] || req.ip).split(',')[0].trim();

  if (ipRangeCheck(clientIP, allowedIPRanges)) {
    next();
  } else {
    console.error(`Download blocked: ${clientIP}`)
    res.status(403).send('Access denied');
  }
};

// Faye Pub Sub
var http = require('http');
var faye = require('faye');

var server = http.createServer(app);
var bayeux = new faye.NodeAdapter({ mount: '/faye' });

// Middleware to check origin for Faye
bayeux.addExtension({
  incoming: function(message, callback) {
    if (message.channel === '/meta/handshake') {
      const origin = message.ext && message.ext.origin;
      if (origin && allowedOrigins.some(allowedOrigin => origin.includes(allowedOrigin))) {
        return callback(message);
      } else {
        console.error(`Blocked Faye connection from origin: ${origin}`);
        message.error = 'Forbidden: Invalid origin';
      }
    }
    callback(message);
  }
});

bayeux.attach(server);

// Replay Data Store
const CREATE_DATA_TABLE = "CREATE TABLE IF NOT EXISTS DATA (ID INTEGER PRIMARY KEY AUTOINCREMENT, TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, DATA TEXT, NAME TEXT);";

app.post('/insert', checkOrigin, (req, res) => {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  let data = req.body.data;
  let name = req.query.name;

  if (name) {
    db.run(`INSERT INTO DATA (NAME, DATA) VALUES (?,?)`, [name, data]);
  } else {
    db.run(`INSERT INTO DATA (DATA) VALUES (?)`, [data]);
  }

  db.close();

  res.status(201).send('Created');
});

app.get('/retrieve', checkOrigin, (req, res) => {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  let name = req.query.name;
  let sql;

  if (name) {
    sql = `SELECT * FROM DATA WHERE NAME=? ORDER BY TIMESTAMP ASC;`;
    db.all(sql, [name], (err, rows) => {
      if (err) {
        throw err;
      }
      res.send(rows);
    });
  } else {
    sql = `SELECT * FROM DATA ORDER BY TIMESTAMP ASC;`;
    db.all(sql, [], (err, rows) => {
      if (err) {
        throw err;
      }
      res.send(rows);
    });
  }

  db.close();
});

app.get('/download', checkIP, (req, res) => {
  const file = './main.db';
  res.download(file, 'main.db', (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error downloading the file');
    }
  });
});

// Run
server.listen(8000, function() {
  let db = new sqlite3.Database('./main.db', (err) => {
    if (err) {
      return console.error(err.message);
    }
  });

  db.run(CREATE_DATA_TABLE);

  db.close();

  console.log("Faye and Server are listening on port 8000");
});