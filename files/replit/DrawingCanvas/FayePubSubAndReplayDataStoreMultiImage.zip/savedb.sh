#!/bin/bash
curl https://faye-pub-sub-and-replay-data-store-multi-image-billjr99.replit.app/download --output main.db
