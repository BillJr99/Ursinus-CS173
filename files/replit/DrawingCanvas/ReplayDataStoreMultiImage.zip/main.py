import sqlite3
from flask import Flask, request
import json
from flask_cors import CORS

CREATE_DATA_TABLE = "CREATE TABLE IF NOT EXISTS DATA (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, DATA TEXT, NAME TEXT);"

app = Flask(__name__)
CORS(app, resources={r"*": {"origins": "*"}})


# https://stackoverflow.com/questions/3300464/how-can-i-get-dict-from-sqlite-query
# use with con.row_factory = dict_factory
def dict_factory(cursor, row):
  d = {}
  for idx, col in enumerate(cursor.description):
    d[col[0]] = row[idx]
  return d


@app.route('/insert', methods=['POST'])
def insert():
  con = sqlite3.connect('main.db')
  res = query(con, CREATE_DATA_TABLE)

  data = str(request.form['data'])
  name = request.args.get('name', default=None)

  if not (name is None):
    res = query(con,
                "INSERT INTO DATA (NAME, DATA) VALUES (?,?)",
                params=(
                  name,
                  data,
                ))
  else:
    res = query(con, "INSERT INTO DATA (DATA) VALUES (?)", params=(data, ))

  con.close()
  return 'Created', 201


@app.route('/retrieve')
def retrieve():
  con = sqlite3.connect('main.db')
  con.row_factory = dict_factory
  res = query(con, CREATE_DATA_TABLE)

  name = request.args.get('name', default=None)

  if not (name is None):
    res = query(con,
                "SELECT * FROM DATA WHERE NAME=? ORDER BY TIMESTAMP ASC;",
                params=(name, ))
  else:
    res = query(con, "SELECT * FROM DATA ORDER BY TIMESTAMP ASC;")
  records = res.fetchall()

  con.close()
  return json.dumps(records)


# stmt contains placeholder ?'s for params
# params is a tuple (val1, val2, ...)
def query(con, stmt, params=None):
  cur = con.cursor()
  if params is None:
    result = cur.execute(stmt)
  else:
    result = cur.execute(stmt, params)
  con.commit()
  return result


if __name__ == '__main__':
  con = sqlite3.connect('main.db')
  res = query(con, CREATE_DATA_TABLE)
  con.close()

  app.run(host='0.0.0.0', debug=True, port=8080, use_reloader=False)
