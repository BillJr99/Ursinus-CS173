// From https://csawesome.runestone.academy/runestone/books/published/csawesome/Unit4-Iteration/FRQselfDivisorA.html

class Main {
   /** @param number the number to be tested
    *         Precondition: number > 0
    *  @return true if every decimal digit of
    *          number is a divisor of number;
    *          false otherwise
    */
   public static boolean isSelfDivisor(int number)
   {
     boolean result = true;

     int val = number;

     while(val > 0 && result == true) { // why a while loop?
       int digit = val % 10;

       if(digit > 0) {
         if(number % digit != 0) {
           result = false;
           // break? or check for result in while? or is either necessary?
         } // which if statement does this curly brace close?
       } else {
         result = false;
         // break? or check for result in while? or is either necessary?
       }

       val = val / 10; // integer division, so this will round down
     }

     return result;
   }

   /****************/

   public static void main (String[] args)
   {
     System.out.println("128: " + isSelfDivisor(128));
     System.out.println("26: " + isSelfDivisor(26));
     System.out.println("120: " + isSelfDivisor(120));
     System.out.println("102: " + isSelfDivisor(102));
   }
}

/*
  STEP 1: print out each digit
   public static boolean isSelfDivisor(int number)
   {
     boolean result = true;

     int val = number;

     while(val > 0) {
       int remainder = val % 10;

       System.out.println(remainder); // 1, 2, 8; 2, 6; 1, 2, 0; 1, 0, 2

       val = val / 10; // integer division, so this will round down
     }

     return result;
   }
*/