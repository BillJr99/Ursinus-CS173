class Main {
  public static void main(String[] args) {
    double rand = Math.random();
    rand = rand * 10;
    rand = Math.ceil(rand);
    if(rand < 1) {
      rand = 1;
    } // or just say rand = Math.max(rand, 1);
    int randInt = (int) rand; // casting from a decimal to a whole number integer

    System.out.println(randInt);
  }
}