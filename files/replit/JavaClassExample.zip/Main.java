public class Main {
  public static void main(String[] args) {
    // Create an object of type Book
    Book b1 = new Book();

    // Create another object of type Book
    Book b2 = new Book();

    /* b1 and b2 are objects - they're each a particular
     * instance of a book.  The Book class defines the 
     * structure that the objects take on, but the objects
     * are what provide the underlying data that make each
     * one distinct */

     b1.author = "F. Scott Fitzgerald";
     b1.title = "The Great Gatsby";
     b1.pages = 218;

     b2.author = "Niccolo Machiavelli";
     b2.title = "The Prince";
     b2.pages = 71;
  }
}